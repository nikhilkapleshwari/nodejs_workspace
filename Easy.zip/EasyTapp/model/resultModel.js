class ResultModel{
    constructor(filename,category,download){
        this.filename=filename;
        this.category=category;
        this.download=download;
    }
}
module.exports = ResultModel;


